1) Install NodeJs LTS version.
2) Extract the zip file
3) Navigate to server directory and run below command:
pnpm i
4) Once done, Edit the index.js file and replace 172.16.69.205 with your system IP.
5) To start, run below command:
node index.js
5) Navigate to client folder and run below commands:
npm i
6) Once done, Edit the src\components\main-chat.jsx file and replace 172.16.69.205 with your system IP. 
7) Once done, to start client application, run below command:
npm run dev
8) Start extracted python application as usual.
9) Open 2 or more browser tabs and Enter below URL:
http://localhost:5173
10) Start the chat.